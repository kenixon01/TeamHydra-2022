public class Monster {
}
