public class Room {
}
