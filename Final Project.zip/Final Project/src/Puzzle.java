public class Puzzle {
}
